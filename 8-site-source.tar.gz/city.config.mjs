export const ACTIVE_CITY = 'northwood-oh';
